<?php

$n = $_POST['nome'];
$e = $_POST['email'];
$s = $_POST['senha'];
$sep = '#$%**&*';
if(file_exists('clientes.txt')){
$linha = "\n". $n . $sep.$e. $sep.$s;
} else{
    $linha = $n . $sep.$e. $sep.$s;
}
$clientes = fopen('clientes.txt', 'a+');
fwrite($clientes, $linha);
fclose($clientes);

?>