<?php
$numero = $_POST["num"];

for ($i =1 ; $i <= $numero; $i++) {
    print $i . " ";
}
?>